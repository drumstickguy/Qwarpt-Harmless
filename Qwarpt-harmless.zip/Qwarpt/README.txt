Well, my first public safe ver of open sourced malwares! (maybe, dummo)
Have fun testing it!




N17Pro3426, VernaTech, OneFive_Malware, Comium97, Comium92, NotCCR, MalwareLab, Marlon2210, gustaa, if yall are seeing this, then hi :)








###########          #     #        #
#                    #    #
#                    #   #          #
#                    #  #           #
###########          ##             #
          #          #  #           #
          #          #   #          #
          #          #    #         #
###########          #     #        #     D! (Sorry, i cant make d, cuz it will look like o)